﻿
namespace _03.WildFarm.Models.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {
        }
    }
}
