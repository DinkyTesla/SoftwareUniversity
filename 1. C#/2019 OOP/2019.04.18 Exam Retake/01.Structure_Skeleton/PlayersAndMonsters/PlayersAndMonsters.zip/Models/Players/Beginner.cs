﻿using System;
using System.Collections.Generic;
using System.Text;
using PlayersAndMonsters.Models.Players.Contracts;
using PlayersAndMonsters.Repositories.Contracts;

namespace PlayersAndMonsters.Models.Players
{
    public class Beginner : Player
    {
        private const int BegginnersHealth = 50;

        public Beginner(ICardRepository cardRepository, string name) 
            : base(cardRepository, name, BegginnersHealth)
        {
        }

    }
}
