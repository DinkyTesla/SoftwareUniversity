﻿namespace AnimalCentre.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
